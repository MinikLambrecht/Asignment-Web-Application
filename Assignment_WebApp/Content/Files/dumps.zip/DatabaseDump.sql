CREATE DATABASE  IF NOT EXISTS `birgerbolcher` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `birgerbolcher`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: birgerbolcher
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `all hardcandy between 10 -to 12g`
--

DROP TABLE IF EXISTS `all hardcandy between 10 -to 12g`;
/*!50001 DROP VIEW IF EXISTS `all hardcandy between 10 -to 12g`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `all hardcandy between 10 -to 12g` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all hardcandy that starts with b`
--

DROP TABLE IF EXISTS `all hardcandy that starts with b`;
/*!50001 DROP VIEW IF EXISTS `all hardcandy that starts with b`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `all hardcandy that starts with b` AS SELECT 
 1 AS `name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all hardcandy under 10g sorted`
--

DROP TABLE IF EXISTS `all hardcandy under 10g sorted`;
/*!50001 DROP VIEW IF EXISTS `all hardcandy under 10g sorted`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `all hardcandy under 10g sorted` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all hardcandy with e in it`
--

DROP TABLE IF EXISTS `all hardcandy with e in it`;
/*!50001 DROP VIEW IF EXISTS `all hardcandy with e in it`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `all hardcandy with e in it` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `all_hardcandy`
--

DROP TABLE IF EXISTS `all_hardcandy`;
/*!50001 DROP VIEW IF EXISTS `all_hardcandy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `all_hardcandy` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `color`
--

DROP TABLE IF EXISTS `color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `color` (
  `ColorID` int(11) NOT NULL AUTO_INCREMENT,
  `ColorValue` varchar(50) NOT NULL,
  PRIMARY KEY (`ColorID`),
  UNIQUE KEY `ColorID_UNIQUE` (`ColorID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `color`
--

LOCK TABLES `color` WRITE;
/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` VALUES (1,'Yellow'),(2,'Red'),(3,'Orange'),(4,'Light Blue'),(5,'Blue'),(6,'Black');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flavour`
--

DROP TABLE IF EXISTS `flavour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `flavour` (
  `FlavourID` int(11) NOT NULL AUTO_INCREMENT,
  `FlavourValue` varchar(50) NOT NULL,
  PRIMARY KEY (`FlavourID`),
  UNIQUE KEY `FlavourID_UNIQUE` (`FlavourID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flavour`
--

LOCK TABLES `flavour` WRITE;
/*!40000 ALTER TABLE `flavour` DISABLE KEYS */;
INSERT INTO `flavour` VALUES (1,'Lemon'),(2,'Banana'),(3,'Strawberry'),(4,'Orange'),(5,'Anis'),(6,'Ammonia');
/*!40000 ALTER TABLE `flavour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hardcandy`
--

DROP TABLE IF EXISTS `hardcandy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `hardcandy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `color` int(11) NOT NULL,
  `weight` decimal(4,0) NOT NULL,
  `flavor sourness` int(11) NOT NULL,
  `flavor strength` int(11) NOT NULL,
  `flavor` int(11) NOT NULL,
  `commodity price(cents)` decimal(5,2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`),
  KEY `fk_hardcandy_strength_idx` (`flavor strength`),
  KEY `fk_hardcandy_sourness1_idx` (`flavor sourness`),
  KEY `fk_hardcandy_flavour1_idx` (`flavor`),
  KEY `fk_hardcandy_color1_idx` (`color`),
  CONSTRAINT `fk_hardcandy_color` FOREIGN KEY (`color`) REFERENCES `color` (`ColorID`),
  CONSTRAINT `fk_hardcandy_flavour1` FOREIGN KEY (`flavor`) REFERENCES `flavour` (`FlavourID`),
  CONSTRAINT `fk_hardcandy_sourness1` FOREIGN KEY (`flavor sourness`) REFERENCES `sourness` (`SournessID`),
  CONSTRAINT `fk_hardcandy_strength1` FOREIGN KEY (`flavor strength`) REFERENCES `strength` (`StrengthID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hardcandy`
--

LOCK TABLES `hardcandy` WRITE;
/*!40000 ALTER TABLE `hardcandy` DISABLE KEYS */;
INSERT INTO `hardcandy` VALUES (1,'Strawberry',2,11,2,1,3,16.00),(2,'Orange',3,12,2,1,4,13.00),(3,'Lemon',1,10,1,1,1,14.00),(4,'Ammonia Cyanide',6,6,2,3,6,12.00),(5,'Blue Shark',4,22,1,2,5,19.00),(6,'Red Pearl',2,8,2,2,3,9.00),(7,'Yellow Pearl',1,8,1,2,1,10.00),(8,'Blue Pearl',5,8,1,3,5,11.00),(9,'Banana Split',1,7,2,3,2,10.00);
/*!40000 ALTER TABLE `hardcandy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `hardcandy aplhabetically`
--

DROP TABLE IF EXISTS `hardcandy aplhabetically`;
/*!50001 DROP VIEW IF EXISTS `hardcandy aplhabetically`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `hardcandy aplhabetically` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `random hardcandy`
--

DROP TABLE IF EXISTS `random hardcandy`;
/*!50001 DROP VIEW IF EXISTS `random hardcandy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `random hardcandy` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `red/blue_hardcandy`
--

DROP TABLE IF EXISTS `red/blue_hardcandy`;
/*!50001 DROP VIEW IF EXISTS `red/blue_hardcandy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `red/blue_hardcandy` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `red_hardcandy`
--

DROP TABLE IF EXISTS `red_hardcandy`;
/*!50001 DROP VIEW IF EXISTS `red_hardcandy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `red_hardcandy` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sourness`
--

DROP TABLE IF EXISTS `sourness`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sourness` (
  `SournessID` int(11) NOT NULL AUTO_INCREMENT,
  `SournessValue` varchar(50) NOT NULL,
  PRIMARY KEY (`SournessID`),
  UNIQUE KEY `SournessID_UNIQUE` (`SournessID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sourness`
--

LOCK TABLES `sourness` WRITE;
/*!40000 ALTER TABLE `sourness` DISABLE KEYS */;
INSERT INTO `sourness` VALUES (1,'Bitter'),(2,'Sweet');
/*!40000 ALTER TABLE `sourness` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `strength`
--

DROP TABLE IF EXISTS `strength`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `strength` (
  `StrengthID` int(11) NOT NULL AUTO_INCREMENT,
  `StrengthValue` varchar(50) NOT NULL,
  PRIMARY KEY (`StrengthID`),
  UNIQUE KEY `StrengthID_UNIQUE` (`StrengthID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `strength`
--

LOCK TABLES `strength` WRITE;
/*!40000 ALTER TABLE `strength` DISABLE KEYS */;
INSERT INTO `strength` VALUES (1,'Mild'),(2,'Medium'),(3,'Strong');
/*!40000 ALTER TABLE `strength` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `top 3 heaviest hardcandy`
--

DROP TABLE IF EXISTS `top 3 heaviest hardcandy`;
/*!50001 DROP VIEW IF EXISTS `top 3 heaviest hardcandy`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `top 3 heaviest hardcandy` AS SELECT 
 1 AS `id`,
 1 AS `name`,
 1 AS `color`,
 1 AS `weight`,
 1 AS `flavor sourness`,
 1 AS `flavor strength`,
 1 AS `flavor`,
 1 AS `commodity price(cents)`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'birgerbolcher'
--

--
-- Final view structure for view `all hardcandy between 10 -to 12g`
--

/*!50001 DROP VIEW IF EXISTS `all hardcandy between 10 -to 12g`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all hardcandy between 10 -to 12g` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where (`hardcandy`.`weight` between '10' and '12') order by `hardcandy`.`name`,`hardcandy`.`weight` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all hardcandy that starts with b`
--

/*!50001 DROP VIEW IF EXISTS `all hardcandy that starts with b`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all hardcandy that starts with b` AS select `hardcandy`.`name` AS `name` from `hardcandy` where (`hardcandy`.`name` like 'B%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all hardcandy under 10g sorted`
--

/*!50001 DROP VIEW IF EXISTS `all hardcandy under 10g sorted`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all hardcandy under 10g sorted` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where (`hardcandy`.`weight` <= '10') order by `hardcandy`.`weight` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all hardcandy with e in it`
--

/*!50001 DROP VIEW IF EXISTS `all hardcandy with e in it`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all hardcandy with e in it` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where (`hardcandy`.`name` like '%e%') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `all_hardcandy`
--

/*!50001 DROP VIEW IF EXISTS `all_hardcandy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `all_hardcandy` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hardcandy aplhabetically`
--

/*!50001 DROP VIEW IF EXISTS `hardcandy aplhabetically`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hardcandy aplhabetically` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where (`hardcandy`.`color` <> 'Red') order by `hardcandy`.`name` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `random hardcandy`
--

/*!50001 DROP VIEW IF EXISTS `random hardcandy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `random hardcandy` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` order by rand() limit 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `red/blue_hardcandy`
--

/*!50001 DROP VIEW IF EXISTS `red/blue_hardcandy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `red/blue_hardcandy` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where ((`hardcandy`.`color` = 'Red') or (`hardcandy`.`color` = 'Blue')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `red_hardcandy`
--

/*!50001 DROP VIEW IF EXISTS `red_hardcandy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `red_hardcandy` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` where (`hardcandy`.`color` = 'red') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `top 3 heaviest hardcandy`
--

/*!50001 DROP VIEW IF EXISTS `top 3 heaviest hardcandy`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `top 3 heaviest hardcandy` AS select `hardcandy`.`id` AS `id`,`hardcandy`.`name` AS `name`,`hardcandy`.`color` AS `color`,`hardcandy`.`weight` AS `weight`,`hardcandy`.`flavor sourness` AS `flavor sourness`,`hardcandy`.`flavor strength` AS `flavor strength`,`hardcandy`.`flavor` AS `flavor`,`hardcandy`.`commodity price(cents)` AS `commodity price(cents)` from `hardcandy` order by `hardcandy`.`weight` desc limit 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-28 10:56:58
